<?php
$pageTitle = 'Estados';
$baseUrl   = '../../';
require_once '../../includes/conexion.php';
require_once '../../includes/header.php';

$conn    = getConexion();
$estados = $conn->query("SELECT * FROM estados ORDER BY id_estado");
$msg     = $_GET['msg'] ?? '';
?>

<div class="breadcrumb-wrapper">
  <nav aria-label="breadcrumb">
    <ol class="breadcrumb mb-0">
      <li class="breadcrumb-item"><a href="<?= $baseUrl ?>index.php">Inicio</a></li>
      <li class="breadcrumb-item active">Estados</li>
    </ol>
  </nav>
</div>

<?php if ($msg === 'creado'):    echo '<div class="alert alert-success alert-dismissible fade show">Estado creado.<button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>'; endif; ?>
<?php if ($msg === 'editado'):   echo '<div class="alert alert-info alert-dismissible fade show">Estado actualizado.<button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>'; endif; ?>
<?php if ($msg === 'eliminado'): echo '<div class="alert alert-warning alert-dismissible fade show">Estado eliminado.<button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>'; endif; ?>

<div class="card">
  <div class="card-header bg-white d-flex justify-content-between align-items-center">
    <span><i class="bi bi-tags-fill me-2 text-warning"></i>Listado de Estados</span>
    <a href="crear.php" class="btn btn-sm btn-primary"><i class="bi bi-plus-lg me-1"></i>Nuevo estado</a>
  </div>
  <div class="card-body p-0">
    <div class="table-responsive">
      <table class="table table-hover mb-0">
        <thead class="table-light">
          <tr><th>#</th><th>Nombre del estado</th><th class="text-center">Acciones</th></tr>
        </thead>
        <tbody>
          <?php if ($estados->num_rows === 0): ?>
            <tr><td colspan="3" class="text-center text-muted py-4">No hay estados registrados.</td></tr>
          <?php else: ?>
            <?php while ($e = $estados->fetch_assoc()): ?>
            <tr>
              <td class="text-muted"><?= $e['id_estado'] ?></td>
              <td><?= htmlspecialchars($e['nombre_estado']) ?></td>
              <td class="text-center">
                <a href="editar.php?id=<?= $e['id_estado'] ?>" class="btn btn-accion btn-outline-secondary me-1"><i class="bi bi-pencil-fill"></i></a>
                <a href="eliminar.php?id=<?= $e['id_estado'] ?>" class="btn btn-accion btn-outline-danger btn-confirmar-eliminar"><i class="bi bi-trash-fill"></i></a>
              </td>
            </tr>
            <?php endwhile; ?>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<?php $conn->close(); require_once '../../includes/footer.php'; ?>
