<?php
$pageTitle = 'Inicio';
$baseUrl   = '';
require_once 'includes/conexion.php';
require_once 'includes/header.php';

$conn = getConexion();

$totalUsuarios = $conn->query("SELECT COUNT(*) AS n FROM usuarios")->fetch_assoc()['n'];
$totalCompras  = $conn->query("SELECT COUNT(*) AS n FROM compras")->fetch_assoc()['n'];
$totalMonto    = $conn->query("SELECT COALESCE(SUM(monto),0) AS n FROM compras")->fetch_assoc()['n'];
$pendientes    = $conn->query("SELECT COUNT(*) AS n FROM compras WHERE id_estado=1")->fetch_assoc()['n'];

// Últimas 5 compras
$ultimas = $conn->query("
  SELECT c.titulo_compra, c.fecha_ejecucion, c.monto,
         u.nombre_usuario, e.nombre_estado
  FROM compras c
  JOIN usuarios u ON c.id_usuario_encargado = u.id_usuario
  JOIN estados  e ON c.id_estado = e.id_estado
  ORDER BY c.id_compra DESC
  LIMIT 5
");
?>

<!-- Hero -->
<div class="hero-banner mb-4">
  <h1 class="h3 fw-bold mb-1"><i class="bi bi-bag-check-fill me-2"></i>compra.me</h1>
  <p class="mb-0 opacity-75">Panel de gestión de gastos · <?= date('d/m/Y') ?></p>
</div>

<!-- Estadísticas -->
<div class="row g-3 mb-4">
  <div class="col-6 col-md-3">
    <div class="stat-card bg-primary text-white">
      <div class="stat-number"><?= $totalUsuarios ?></div>
      <div class="stat-label">Usuarios</div>
    </div>
  </div>
  <div class="col-6 col-md-3">
    <div class="stat-card bg-success text-white">
      <div class="stat-number"><?= $totalCompras ?></div>
      <div class="stat-label">Compras</div>
    </div>
  </div>
  <div class="col-6 col-md-3">
    <div class="stat-card bg-info text-white">
      <div class="stat-number">Q<?= number_format($totalMonto, 2) ?></div>
      <div class="stat-label">Monto total</div>
    </div>
  </div>
  <div class="col-6 col-md-3">
    <div class="stat-card bg-warning">
      <div class="stat-number"><?= $pendientes ?></div>
      <div class="stat-label">Pendientes</div>
    </div>
  </div>
</div>

<!-- Accesos rápidos -->
<div class="row g-3 mb-4">
  <div class="col-12 col-md-4">
    <a href="modulos/usuarios/listar.php" class="card text-decoration-none text-dark h-100">
      <div class="card-body d-flex align-items-center gap-3">
        <span class="fs-2 text-primary"><i class="bi bi-people-fill"></i></span>
        <div>
          <h6 class="mb-0 fw-semibold">Gestión de Usuarios</h6>
          <small class="text-muted">Agregar, editar y eliminar usuarios</small>
        </div>
      </div>
    </a>
  </div>
  <div class="col-12 col-md-4">
    <a href="modulos/compras/listar.php" class="card text-decoration-none text-dark h-100">
      <div class="card-body d-flex align-items-center gap-3">
        <span class="fs-2 text-success"><i class="bi bi-cart3"></i></span>
        <div>
          <h6 class="mb-0 fw-semibold">Gestión de Compras</h6>
          <small class="text-muted">Registrar y controlar gastos</small>
        </div>
      </div>
    </a>
  </div>
  <div class="col-12 col-md-4">
    <a href="modulos/estados/listar.php" class="card text-decoration-none text-dark h-100">
      <div class="card-body d-flex align-items-center gap-3">
        <span class="fs-2 text-warning"><i class="bi bi-tags-fill"></i></span>
        <div>
          <h6 class="mb-0 fw-semibold">Gestión de Estados</h6>
          <small class="text-muted">Configurar estados de compra</small>
        </div>
      </div>
    </a>
  </div>
</div>

<!-- Últimas compras -->
<div class="card">
  <div class="card-header bg-white d-flex justify-content-between align-items-center">
    <span><i class="bi bi-clock-history me-2 text-primary"></i>Últimas compras registradas</span>
    <a href="modulos/compras/crear.php" class="btn btn-sm btn-primary">
      <i class="bi bi-plus-lg me-1"></i>Nueva
    </a>
  </div>
  <div class="card-body p-0">
    <div class="table-responsive">
      <table class="table table-hover mb-0">
        <thead class="table-light">
          <tr>
            <th>Título</th>
            <th>Usuario</th>
            <th>Fecha</th>
            <th>Monto</th>
            <th>Estado</th>
          </tr>
        </thead>
        <tbody>
          <?php if ($ultimas->num_rows === 0): ?>
            <tr><td colspan="5" class="text-center text-muted py-3">No hay compras registradas aún.</td></tr>
          <?php else: ?>
            <?php while ($row = $ultimas->fetch_assoc()): ?>
            <tr>
              <td><?= htmlspecialchars($row['titulo_compra']) ?></td>
              <td><?= htmlspecialchars($row['nombre_usuario']) ?></td>
              <td><?= htmlspecialchars($row['fecha_ejecucion']) ?></td>
              <td>Q<?= number_format($row['monto'], 2) ?></td>
              <td>
                <?php
                  $slug = strtolower(str_replace(' ', '-', $row['nombre_estado']));
                  echo "<span class='badge badge-{$slug}'>" . htmlspecialchars($row['nombre_estado']) . "</span>";
                ?>
              </td>
            </tr>
            <?php endwhile; ?>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<?php
$conn->close();
require_once 'includes/footer.php';
?>
