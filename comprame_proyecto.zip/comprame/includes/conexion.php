<?php
// ============================================================
//  compra.me  |  Conexión a la base de datos
// ============================================================
define('DB_HOST',   'localhost');
define('DB_USER',   'root');       // Cambiar en producción
define('DB_PASS',   '');           // Cambiar en producción
define('DB_NAME',   'comprame_db');
define('DB_CHARSET','utf8mb4');

function getConexion(): mysqli {
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    if ($conn->connect_error) {
        http_response_code(500);
        die(json_encode(['error' => 'Error de conexión: ' . $conn->connect_error]));
    }
    $conn->set_charset(DB_CHARSET);
    return $conn;
}
