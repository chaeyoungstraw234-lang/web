<?php
$pageTitle = 'Editar Usuario';
$baseUrl   = '../../';
require_once '../../includes/conexion.php';

$conn = getConexion();
$id   = intval($_GET['id'] ?? 0);

// Obtener usuario existente
$stmt = $conn->prepare("SELECT * FROM usuarios WHERE id_usuario = ?");
$stmt->bind_param('i', $id);
$stmt->execute();
$usuario = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$usuario) {
    header('Location: listar.php');
    exit;
}

$errores = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre    = trim($_POST['nombre']    ?? '');
    $email     = trim($_POST['email']     ?? '');
    $telefono  = trim($_POST['telefono']  ?? '');
    $direccion = trim($_POST['direccion'] ?? '');

    if (empty($nombre)) $errores[] = 'El nombre es obligatorio.';
    if (empty($email))  $errores[] = 'El correo es obligatorio.';
    elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errores[] = 'Correo electrónico inválido.';

    if (empty($errores)) {
        $upd = $conn->prepare("UPDATE usuarios SET nombre_usuario=?, email_usuario=?, telefono_usuario=?, direccion_usuario=? WHERE id_usuario=?");
        $upd->bind_param('ssssi', $nombre, $email, $telefono, $direccion, $id);
        if ($upd->execute()) {
            header('Location: listar.php?msg=editado');
            exit;
        }
        $errores[] = 'Error al actualizar: ' . htmlspecialchars($conn->error);
        $upd->close();
    }
    // Mantener valores del POST en caso de error
    $usuario['nombre_usuario']    = $nombre;
    $usuario['email_usuario']     = $email;
    $usuario['telefono_usuario']  = $telefono;
    $usuario['direccion_usuario'] = $direccion;
}

$conn->close();
require_once '../../includes/header.php';
?>

<div class="breadcrumb-wrapper">
  <nav aria-label="breadcrumb">
    <ol class="breadcrumb mb-0">
      <li class="breadcrumb-item"><a href="<?= $baseUrl ?>index.php">Inicio</a></li>
      <li class="breadcrumb-item"><a href="listar.php">Usuarios</a></li>
      <li class="breadcrumb-item active">Editar</li>
    </ol>
  </nav>
</div>

<?php if (!empty($errores)): ?>
<div class="alert alert-danger">
  <ul class="mb-0"><?php foreach ($errores as $e): ?><li><?= $e ?></li><?php endforeach; ?></ul>
</div>
<?php endif; ?>

<div class="card mx-auto" style="max-width:600px">
  <div class="card-header bg-white">
    <i class="bi bi-pencil-fill me-2 text-secondary"></i>Editar Usuario #<?= $id ?>
  </div>
  <div class="card-body">
    <form method="POST" class="needs-validation" novalidate>
      <div class="mb-3">
        <label class="form-label" for="nombre">Nombre completo <span class="text-danger">*</span></label>
        <input type="text" id="nombre" name="nombre" class="form-control" required maxlength="100"
               value="<?= htmlspecialchars($usuario['nombre_usuario']) ?>">
        <div class="invalid-feedback">El nombre es obligatorio.</div>
      </div>
      <div class="mb-3">
        <label class="form-label" for="email">Correo electrónico <span class="text-danger">*</span></label>
        <input type="email" id="email" name="email" class="form-control" required maxlength="150"
               value="<?= htmlspecialchars($usuario['email_usuario']) ?>">
        <div class="invalid-feedback">Ingresa un correo válido.</div>
      </div>
      <div class="mb-3">
        <label class="form-label" for="telefono">Teléfono</label>
        <input type="text" id="telefono" name="telefono" class="form-control" maxlength="20" data-tipo="telefono"
               value="<?= htmlspecialchars($usuario['telefono_usuario'] ?? '') ?>">
      </div>
      <div class="mb-4">
        <label class="form-label" for="direccion">Dirección</label>
        <textarea id="direccion" name="direccion" class="form-control" rows="2" maxlength="255"><?= htmlspecialchars($usuario['direccion_usuario'] ?? '') ?></textarea>
      </div>
      <div class="d-flex gap-2">
        <button type="submit" class="btn btn-primary"><i class="bi bi-save me-1"></i>Actualizar</button>
        <a href="listar.php" class="btn btn-outline-secondary">Cancelar</a>
      </div>
    </form>
  </div>
</div>

<?php require_once '../../includes/footer.php'; ?>
