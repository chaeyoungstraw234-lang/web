<?php
$pageTitle = 'Nueva Compra';
$baseUrl   = '../../';
require_once '../../includes/conexion.php';

$conn     = getConexion();
$usuarios = $conn->query("SELECT id_usuario, nombre_usuario FROM usuarios ORDER BY nombre_usuario");
$estados  = $conn->query("SELECT id_estado, nombre_estado FROM estados ORDER BY id_estado");

$errores = [];
$datos   = ['titulo' => '', 'descripcion' => '', 'fecha' => '', 'monto' => '', 'usuario' => '', 'estado' => '1'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $datos['titulo']      = trim($_POST['titulo']      ?? '');
    $datos['descripcion'] = trim($_POST['descripcion'] ?? '');
    $datos['fecha']       = trim($_POST['fecha']       ?? '');
    $datos['monto']       = trim($_POST['monto']       ?? '');
    $datos['usuario']     = intval($_POST['usuario']   ?? 0);
    $datos['estado']      = intval($_POST['estado']    ?? 0);

    if (empty($datos['titulo']))  $errores[] = 'El título es obligatorio.';
    if (empty($datos['fecha']))   $errores[] = 'La fecha de ejecución es obligatoria.';
    if ($datos['usuario'] <= 0)   $errores[] = 'Selecciona un usuario encargado.';
    if ($datos['estado']  <= 0)   $errores[] = 'Selecciona un estado.';
    if (!is_numeric($datos['monto']) || $datos['monto'] < 0) $errores[] = 'El monto debe ser un número positivo.';

    if (empty($errores)) {
        $stmt = $conn->prepare("INSERT INTO compras (titulo_compra, descripcion_compra, fecha_ejecucion, monto, id_usuario_encargado, id_estado) VALUES (?,?,?,?,?,?)");
        $stmt->bind_param('sssdii', $datos['titulo'], $datos['descripcion'], $datos['fecha'], $datos['monto'], $datos['usuario'], $datos['estado']);
        if ($stmt->execute()) { header('Location: listar.php?msg=creado'); exit; }
        $errores[] = 'Error al guardar: ' . htmlspecialchars($conn->error);
        $stmt->close();
    }
}

require_once '../../includes/header.php';
?>

<div class="breadcrumb-wrapper">
  <nav aria-label="breadcrumb">
    <ol class="breadcrumb mb-0">
      <li class="breadcrumb-item"><a href="<?= $baseUrl ?>index.php">Inicio</a></li>
      <li class="breadcrumb-item"><a href="listar.php">Compras</a></li>
      <li class="breadcrumb-item active">Nueva</li>
    </ol>
  </nav>
</div>

<?php if (!empty($errores)): ?><div class="alert alert-danger"><ul class="mb-0"><?php foreach ($errores as $e): ?><li><?= $e ?></li><?php endforeach; ?></ul></div><?php endif; ?>

<div class="card mx-auto" style="max-width:640px">
  <div class="card-header bg-white"><i class="bi bi-cart-plus-fill me-2 text-success"></i>Nueva Compra</div>
  <div class="card-body">
    <form method="POST" class="needs-validation" novalidate>
      <div class="mb-3">
        <label class="form-label" for="titulo">Título <span class="text-danger">*</span></label>
        <input type="text" id="titulo" name="titulo" class="form-control" required maxlength="150"
               value="<?= htmlspecialchars($datos['titulo']) ?>" placeholder="Descripción breve de la compra">
        <div class="invalid-feedback">El título es obligatorio.</div>
      </div>
      <div class="mb-3">
        <label class="form-label" for="descripcion">Descripción</label>
        <textarea id="descripcion" name="descripcion" class="form-control" rows="3"
                  placeholder="Detalles adicionales de la compra..."><?= htmlspecialchars($datos['descripcion']) ?></textarea>
      </div>
      <div class="row g-3 mb-3">
        <div class="col-sm-6">
          <label class="form-label" for="fecha">Fecha de ejecución <span class="text-danger">*</span></label>
          <input type="date" id="fecha" name="fecha" class="form-control" required
                 value="<?= htmlspecialchars($datos['fecha']) ?>">
          <div class="invalid-feedback">La fecha es obligatoria.</div>
        </div>
        <div class="col-sm-6">
          <label class="form-label" for="monto">Monto (Q) <span class="text-danger">*</span></label>
          <input type="number" id="monto" name="monto" class="form-control" min="0" step="0.01" required
                 value="<?= htmlspecialchars($datos['monto']) ?>" placeholder="0.00">
          <div class="invalid-feedback">Ingresa un monto válido.</div>
        </div>
      </div>
      <div class="row g-3 mb-4">
        <div class="col-sm-6">
          <label class="form-label" for="usuario">Usuario encargado <span class="text-danger">*</span></label>
          <select id="usuario" name="usuario" class="form-select" required>
            <option value="">— Seleccionar —</option>
            <?php
              $usuarios->data_seek(0);
              while ($u = $usuarios->fetch_assoc()):
                $sel = ($datos['usuario'] == $u['id_usuario']) ? 'selected' : '';
            ?>
            <option value="<?= $u['id_usuario'] ?>" <?= $sel ?>><?= htmlspecialchars($u['nombre_usuario']) ?></option>
            <?php endwhile; ?>
          </select>
          <div class="invalid-feedback">Selecciona un usuario.</div>
        </div>
        <div class="col-sm-6">
          <label class="form-label" for="estado">Estado <span class="text-danger">*</span></label>
          <select id="estado" name="estado" class="form-select" required>
            <option value="">— Seleccionar —</option>
            <?php
              $estados->data_seek(0);
              while ($e = $estados->fetch_assoc()):
                $sel = ($datos['estado'] == $e['id_estado']) ? 'selected' : '';
            ?>
            <option value="<?= $e['id_estado'] ?>" <?= $sel ?>><?= htmlspecialchars($e['nombre_estado']) ?></option>
            <?php endwhile; ?>
          </select>
          <div class="invalid-feedback">Selecciona un estado.</div>
        </div>
      </div>
      <div class="d-flex gap-2">
        <button type="submit" class="btn btn-primary"><i class="bi bi-save me-1"></i>Guardar</button>
        <a href="listar.php" class="btn btn-outline-secondary">Cancelar</a>
      </div>
    </form>
  </div>
</div>

<?php $conn->close(); require_once '../../includes/footer.php'; ?>
