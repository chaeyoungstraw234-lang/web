<?php
$pageTitle = 'Eliminar Estado';
$baseUrl   = '../../';
require_once '../../config/conexion.php';

$conn = getConexion();
$id   = intval($_GET['id'] ?? 0);

$stmt = $conn->prepare("SELECT * FROM estados WHERE id_estado = ?");
$stmt->bind_param('i', $id);
$stmt->execute();
$estado = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$estado) { header('Location: listar.php'); exit; }

$chk = $conn->prepare("SELECT COUNT(*) AS n FROM compras WHERE id_estado = ?");
$chk->bind_param('i', $id);
$chk->execute();
$numCompras = $chk->get_result()->fetch_assoc()['n'];
$chk->close();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $numCompras == 0) {
    $del = $conn->prepare("DELETE FROM estados WHERE id_estado = ?");
    $del->bind_param('i', $id);
    $del->execute(); $del->close(); $conn->close();
    header('Location: listar.php?msg=eliminado'); exit;
}

$conn->close();
require_once '../../config/header.php';
?>

<div class="breadcrumb-wrapper">
  <nav aria-label="breadcrumb">
    <ol class="breadcrumb mb-0">
      <li class="breadcrumb-item"><a href="<?= $baseUrl ?>index.php">Inicio</a></li>
      <li class="breadcrumb-item"><a href="listar.php">Estados</a></li>
      <li class="breadcrumb-item active">Eliminar</li>
    </ol>
  </nav>
</div>

<div class="card mx-auto border-danger" style="max-width:500px">
  <div class="card-header bg-danger text-white"><i class="bi bi-exclamation-triangle-fill me-2"></i>Confirmar eliminación</div>
  <div class="card-body">
    <?php if ($numCompras > 0): ?>
      <div class="alert alert-warning">No se puede eliminar el estado <strong><?= htmlspecialchars($estado['nombre_estado']) ?></strong> porque está asignado a <strong><?= $numCompras ?></strong> compra(s).</div>
      <a href="listar.php" class="btn btn-secondary">Volver</a>
    <?php else: ?>
      <p>¿Eliminar el estado <strong><?= htmlspecialchars($estado['nombre_estado']) ?></strong>?</p>
      <form method="POST" class="d-flex gap-2">
        <button type="submit" class="btn btn-danger"><i class="bi bi-trash-fill me-1"></i>Sí, eliminar</button>
        <a href="listar.php" class="btn btn-outline-secondary">Cancelar</a>
      </form>
    <?php endif; ?>
  </div>
</div>

<?php require_once '../../config/footer.php'; ?>