<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>compra.me | <?= htmlspecialchars($pageTitle ?? 'Sistema de Gastos') ?></title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
  <link href="<?= $baseUrl ?? '' ?>css/estilos.css" rel="stylesheet">
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-primary shadow-sm">
  <div class="container">
    <a class="navbar-brand fw-bold" href="<?= $baseUrl ?? '' ?>index.php">
      <i class="bi bi-bag-check-fill me-2"></i>compra.me
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navMenu">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navMenu">
      <ul class="navbar-nav ms-auto gap-1">
        <li class="nav-item">
          <a class="nav-link <?= (strpos($_SERVER['PHP_SELF'],'usuarios') !== false) ? 'active' : '' ?>"
             href="<?= $baseUrl ?? '' ?>modulos/usuarios/listar.php">
            <i class="bi bi-people-fill me-1"></i>Usuarios
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link <?= (strpos($_SERVER['PHP_SELF'],'compras') !== false) ? 'active' : '' ?>"
             href="<?= $baseUrl ?? '' ?>modulos/compras/listar.php">
            <i class="bi bi-cart3 me-1"></i>Compras
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link <?= (strpos($_SERVER['PHP_SELF'],'estados') !== false) ? 'active' : '' ?>"
             href="<?= $baseUrl ?? '' ?>modulos/estados/listar.php">
            <i class="bi bi-tags-fill me-1"></i>Estados
          </a>
        </li>
      </ul>
    </div>
  </div>
</nav>

<!-- Contenido -->
<div class="container my-4">
