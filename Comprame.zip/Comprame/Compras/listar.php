<?php
$pageTitle = 'Compras';
$baseUrl   = '../../';
require_once '../../config/conexion.php';
require_once '../../config/header.php';

$conn = getConexion();
$msg  = $_GET['msg'] ?? '';

$compras = $conn->query("
  SELECT c.id_compra, c.titulo_compra, c.fecha_ejecucion, c.monto,
         u.nombre_usuario, e.nombre_estado
  FROM compras c
  JOIN usuarios u ON c.id_usuario_encargado = u.id_usuario
  JOIN estados  e ON c.id_estado = e.id_estado
  ORDER BY c.fecha_ejecucion DESC
");
?>

<div class="breadcrumb-wrapper">
  <nav aria-label="breadcrumb">
    <ol class="breadcrumb mb-0">
      <li class="breadcrumb-item"><a href="<?= $baseUrl ?>index.php">Inicio</a></li>
      <li class="breadcrumb-item active">Compras</li>
    </ol>
  </nav>
</div>

<?php if ($msg === 'creado'):    echo '<div class="alert alert-success alert-dismissible fade show"><i class="bi bi-check-circle me-2"></i>Compra registrada.<button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>'; endif; ?>
<?php if ($msg === 'editado'):   echo '<div class="alert alert-info alert-dismissible fade show"><i class="bi bi-pencil me-2"></i>Compra actualizada.<button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>'; endif; ?>
<?php if ($msg === 'eliminado'): echo '<div class="alert alert-warning alert-dismissible fade show"><i class="bi bi-trash me-2"></i>Compra eliminada.<button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>'; endif; ?>

<div class="card">
  <div class="card-header bg-white d-flex justify-content-between align-items-center">
    <span><i class="bi bi-cart3 me-2 text-success"></i>Listado de Compras</span>
    <a href="crear.php" class="btn btn-sm btn-primary"><i class="bi bi-plus-lg me-1"></i>Nueva compra</a>
  </div>
  <div class="card-body p-0">
    <div class="table-responsive">
      <table class="table table-hover mb-0">
        <thead class="table-light">
          <tr>
            <th>#</th>
            <th>Título</th>
            <th>Usuario encargado</th>
            <th>Fecha</th>
            <th>Monto</th>
            <th>Estado</th>
            <th class="text-center">Acciones</th>
          </tr>
        </thead>
        <tbody>
          <?php if ($compras->num_rows === 0): ?>
            <tr><td colspan="7" class="text-center text-muted py-4">No hay compras registradas.</td></tr>
          <?php else: ?>
            <?php while ($c = $compras->fetch_assoc()): ?>
            <tr>
              <td class="text-muted"><?= $c['id_compra'] ?></td>
              <td><?= htmlspecialchars($c['titulo_compra']) ?></td>
              <td><?= htmlspecialchars($c['nombre_usuario']) ?></td>
              <td><?= htmlspecialchars($c['fecha_ejecucion']) ?></td>
              <td>Q<?= number_format($c['monto'], 2) ?></td>
              <td>
                <?php
                  $slug = strtolower(str_replace(' ', '-', $c['nombre_estado']));
                  echo "<span class='badge badge-{$slug}'>" . htmlspecialchars($c['nombre_estado']) . "</span>";
                ?>
              </td>
              <td class="text-center">
                <a href="editar.php?id=<?= $c['id_compra'] ?>" class="btn btn-accion btn-outline-secondary me-1"><i class="bi bi-pencil-fill"></i></a>
                <a href="eliminar.php?id=<?= $c['id_compra'] ?>" class="btn btn-accion btn-outline-danger btn-confirmar-eliminar"><i class="bi bi-trash-fill"></i></a>
              </td>
            </tr>
            <?php endwhile; ?>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<?php $conn->close(); require_once '../../cofig/footer.php'; ?>
