<?php
$pageTitle = 'Nuevo Usuario';
$baseUrl   = '../../';
require_once '../../includes/conexion.php';

$errores = [];
$datos   = ['nombre' => '', 'email' => '', 'telefono' => '', 'direccion' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $datos['nombre']    = trim($_POST['nombre']    ?? '');
    $datos['email']     = trim($_POST['email']     ?? '');
    $datos['telefono']  = trim($_POST['telefono']  ?? '');
    $datos['direccion'] = trim($_POST['direccion'] ?? '');

    // Validación servidor
    if (empty($datos['nombre']))  $errores[] = 'El nombre es obligatorio.';
    if (empty($datos['email']))   $errores[] = 'El correo es obligatorio.';
    elseif (!filter_var($datos['email'], FILTER_VALIDATE_EMAIL)) $errores[] = 'Correo electrónico inválido.';

    if (empty($errores)) {
        $conn = getConexion();
        $stmt = $conn->prepare("INSERT INTO usuarios (nombre_usuario, email_usuario, telefono_usuario, direccion_usuario) VALUES (?, ?, ?, ?)");
        $stmt->bind_param('ssss', $datos['nombre'], $datos['email'], $datos['telefono'], $datos['direccion']);
        if ($stmt->execute()) {
            header('Location: listar.php?msg=creado');
            exit;
        } else {
            $errores[] = 'Error al guardar: ' . htmlspecialchars($conn->error);
        }
        $stmt->close();
        $conn->close();
    }
}

require_once '../../includes/header.php';
?>

<div class="breadcrumb-wrapper">
  <nav aria-label="breadcrumb">
    <ol class="breadcrumb mb-0">
      <li class="breadcrumb-item"><a href="<?= $baseUrl ?>index.php">Inicio</a></li>
      <li class="breadcrumb-item"><a href="listar.php">Usuarios</a></li>
      <li class="breadcrumb-item active">Nuevo</li>
    </ol>
  </nav>
</div>

<?php if (!empty($errores)): ?>
<div class="alert alert-danger">
  <ul class="mb-0">
    <?php foreach ($errores as $e): ?><li><?= $e ?></li><?php endforeach; ?>
  </ul>
</div>
<?php endif; ?>

<div class="card mx-auto" style="max-width:600px">
  <div class="card-header bg-white">
    <i class="bi bi-person-plus-fill me-2 text-primary"></i>Nuevo Usuario
  </div>
  <div class="card-body">
    <form method="POST" class="needs-validation" novalidate>
      <div class="mb-3">
        <label class="form-label" for="nombre">Nombre completo <span class="text-danger">*</span></label>
        <input type="text" id="nombre" name="nombre" class="form-control"
               value="<?= htmlspecialchars($datos['nombre']) ?>" required maxlength="100">
        <div class="invalid-feedback">El nombre es obligatorio.</div>
      </div>
      <div class="mb-3">
        <label class="form-label" for="email">Correo electrónico <span class="text-danger">*</span></label>
        <input type="email" id="email" name="email" class="form-control"
               value="<?= htmlspecialchars($datos['email']) ?>" required maxlength="150">
        <div class="invalid-feedback">Ingresa un correo válido.</div>
      </div>
      <div class="mb-3">
        <label class="form-label" for="telefono">Teléfono</label>
        <input type="text" id="telefono" name="telefono" class="form-control"
               value="<?= htmlspecialchars($datos['telefono']) ?>" maxlength="20" data-tipo="telefono"
               placeholder="Ej. 5555-1234">
      </div>
      <div class="mb-4">
        <label class="form-label" for="direccion">Dirección</label>
        <textarea id="direccion" name="direccion" class="form-control" rows="2" maxlength="255"
                  placeholder="Zona, municipio, departamento"><?= htmlspecialchars($datos['direccion']) ?></textarea>
      </div>
      <div class="d-flex gap-2">
        <button type="submit" class="btn btn-primary">
          <i class="bi bi-save me-1"></i>Guardar
        </button>
        <a href="listar.php" class="btn btn-outline-secondary">Cancelar</a>
      </div>
    </form>
  </div>
</div>

<?php require_once '../../includes/footer.php'; ?>
