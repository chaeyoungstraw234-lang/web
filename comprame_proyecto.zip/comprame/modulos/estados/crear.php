<?php
$pageTitle = 'Nuevo Estado';
$baseUrl   = '../../';
require_once '../../includes/conexion.php';

$errores = [];
$nombre  = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = trim($_POST['nombre'] ?? '');
    if (empty($nombre)) $errores[] = 'El nombre del estado es obligatorio.';

    if (empty($errores)) {
        $conn = getConexion();
        $stmt = $conn->prepare("INSERT INTO estados (nombre_estado) VALUES (?)");
        $stmt->bind_param('s', $nombre);
        if ($stmt->execute()) { header('Location: listar.php?msg=creado'); exit; }
        $errores[] = 'Error: ' . htmlspecialchars($conn->error);
        $stmt->close(); $conn->close();
    }
}

require_once '../../includes/header.php';
?>

<div class="breadcrumb-wrapper">
  <nav aria-label="breadcrumb">
    <ol class="breadcrumb mb-0">
      <li class="breadcrumb-item"><a href="<?= $baseUrl ?>index.php">Inicio</a></li>
      <li class="breadcrumb-item"><a href="listar.php">Estados</a></li>
      <li class="breadcrumb-item active">Nuevo</li>
    </ol>
  </nav>
</div>

<?php if (!empty($errores)): ?><div class="alert alert-danger"><ul class="mb-0"><?php foreach ($errores as $e): ?><li><?= $e ?></li><?php endforeach; ?></ul></div><?php endif; ?>

<div class="card mx-auto" style="max-width:500px">
  <div class="card-header bg-white"><i class="bi bi-tag-fill me-2 text-warning"></i>Nuevo Estado</div>
  <div class="card-body">
    <form method="POST" class="needs-validation" novalidate>
      <div class="mb-4">
        <label class="form-label" for="nombre">Nombre del estado <span class="text-danger">*</span></label>
        <input type="text" id="nombre" name="nombre" class="form-control" required maxlength="50"
               value="<?= htmlspecialchars($nombre) ?>" placeholder="Ej. En revisión">
        <div class="invalid-feedback">Este campo es obligatorio.</div>
      </div>
      <div class="d-flex gap-2">
        <button type="submit" class="btn btn-primary"><i class="bi bi-save me-1"></i>Guardar</button>
        <a href="listar.php" class="btn btn-outline-secondary">Cancelar</a>
      </div>
    </form>
  </div>
</div>

<?php require_once '../../includes/footer.php'; ?>
