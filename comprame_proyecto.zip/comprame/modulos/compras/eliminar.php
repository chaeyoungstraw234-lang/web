<?php
$pageTitle = 'Eliminar Compra';
$baseUrl   = '../../';
require_once '../../includes/conexion.php';

$conn = getConexion();
$id   = intval($_GET['id'] ?? 0);

$stmt = $conn->prepare("
  SELECT c.*, u.nombre_usuario, e.nombre_estado
  FROM compras c
  JOIN usuarios u ON c.id_usuario_encargado = u.id_usuario
  JOIN estados  e ON c.id_estado = e.id_estado
  WHERE c.id_compra = ?
");
$stmt->bind_param('i', $id);
$stmt->execute();
$compra = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$compra) { header('Location: listar.php'); exit; }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $del = $conn->prepare("DELETE FROM compras WHERE id_compra = ?");
    $del->bind_param('i', $id);
    $del->execute(); $del->close(); $conn->close();
    header('Location: listar.php?msg=eliminado'); exit;
}

$conn->close();
require_once '../../includes/header.php';
?>

<div class="breadcrumb-wrapper">
  <nav aria-label="breadcrumb">
    <ol class="breadcrumb mb-0">
      <li class="breadcrumb-item"><a href="<?= $baseUrl ?>index.php">Inicio</a></li>
      <li class="breadcrumb-item"><a href="listar.php">Compras</a></li>
      <li class="breadcrumb-item active">Eliminar</li>
    </ol>
  </nav>
</div>

<div class="card mx-auto border-danger" style="max-width:540px">
  <div class="card-header bg-danger text-white">
    <i class="bi bi-exclamation-triangle-fill me-2"></i>Confirmar eliminación
  </div>
  <div class="card-body">
    <p>¿Estás seguro de que deseas eliminar la siguiente compra?</p>
    <table class="table table-sm mb-4">
      <tr><th>Título</th><td><?= htmlspecialchars($compra['titulo_compra']) ?></td></tr>
      <tr><th>Encargado</th><td><?= htmlspecialchars($compra['nombre_usuario']) ?></td></tr>
      <tr><th>Fecha</th><td><?= htmlspecialchars($compra['fecha_ejecucion']) ?></td></tr>
      <tr><th>Monto</th><td>Q<?= number_format($compra['monto'], 2) ?></td></tr>
      <tr><th>Estado</th><td><?= htmlspecialchars($compra['nombre_estado']) ?></td></tr>
    </table>
    <p class="text-muted small">Esta acción no se puede deshacer.</p>
    <form method="POST" class="d-flex gap-2">
      <button type="submit" class="btn btn-danger"><i class="bi bi-trash-fill me-1"></i>Sí, eliminar</button>
      <a href="listar.php" class="btn btn-outline-secondary">Cancelar</a>
    </form>
  </div>
</div>

<?php require_once '../../includes/footer.php'; ?>
