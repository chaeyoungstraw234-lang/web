// compra.me – Validación de formularios (Bootstrap 5)
(function () {
  'use strict';

  // Activar validación HTML5 con estilos Bootstrap
  const forms = document.querySelectorAll('.needs-validation');
  forms.forEach(function (form) {
    form.addEventListener('submit', function (event) {
      if (!form.checkValidity()) {
        event.preventDefault();
        event.stopPropagation();
      }
      form.classList.add('was-validated');
    }, false);
  });

  // Validar email en tiempo real
  const emailInputs = document.querySelectorAll('input[type="email"]');
  emailInputs.forEach(function (input) {
    input.addEventListener('blur', function () {
      const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (input.value && !re.test(input.value)) {
        input.setCustomValidity('Correo electrónico inválido.');
        input.classList.add('is-invalid');
      } else {
        input.setCustomValidity('');
        input.classList.remove('is-invalid');
      }
    });
  });

  // Validar teléfono (solo dígitos, guiones, espacios)
  const telInputs = document.querySelectorAll('input[data-tipo="telefono"]');
  telInputs.forEach(function (input) {
    input.addEventListener('input', function () {
      input.value = input.value.replace(/[^0-9\s\-\+\(\)]/g, '');
    });
  });

  // Confirmar eliminación
  const btnEliminar = document.querySelectorAll('.btn-confirmar-eliminar');
  btnEliminar.forEach(function (btn) {
    btn.addEventListener('click', function (e) {
      if (!confirm('¿Estás seguro de que deseas eliminar este registro? Esta acción no se puede deshacer.')) {
        e.preventDefault();
      }
    });
  });
})();
