-- ============================================================
--  compra.me  |  Sistema de Gestión de Gastos
--  Base de datos normalizada en 3FN
-- ============================================================

CREATE DATABASE IF NOT EXISTS comprame_db
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE comprame_db;

-- ------------------------------------------------------------
-- Tabla: estados
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS estados (
  id_estado      INT          NOT NULL AUTO_INCREMENT,
  nombre_estado  VARCHAR(50)  NOT NULL,
  PRIMARY KEY (id_estado),
  UNIQUE KEY uq_nombre_estado (nombre_estado)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Valores iniciales
INSERT INTO estados (nombre_estado) VALUES
  ('Pendiente'),
  ('En proceso'),
  ('Finalizada'),
  ('Cancelada');

-- ------------------------------------------------------------
-- Tabla: usuarios
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS usuarios (
  id_usuario        INT           NOT NULL AUTO_INCREMENT,
  nombre_usuario    VARCHAR(100)  NOT NULL,
  email_usuario     VARCHAR(150)  NOT NULL,
  telefono_usuario  VARCHAR(20)   DEFAULT NULL,
  direccion_usuario VARCHAR(255)  DEFAULT NULL,
  PRIMARY KEY (id_usuario),
  UNIQUE KEY uq_email (email_usuario)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------------------------------------------------------------
-- Tabla: compras
-- Relaciones:
--   id_usuario_encargado → usuarios(id_usuario)   [1:N]
--   id_estado            → estados(id_estado)      [1:N]
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS compras (
  id_compra             INT           NOT NULL AUTO_INCREMENT,
  titulo_compra         VARCHAR(150)  NOT NULL,
  descripcion_compra    TEXT          DEFAULT NULL,
  fecha_ejecucion       DATE          NOT NULL,
  monto                 DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  id_usuario_encargado  INT           NOT NULL,
  id_estado             INT           NOT NULL DEFAULT 1,
  PRIMARY KEY (id_compra),
  KEY fk_compra_usuario (id_usuario_encargado),
  KEY fk_compra_estado  (id_estado),
  CONSTRAINT fk_compra_usuario FOREIGN KEY (id_usuario_encargado)
    REFERENCES usuarios (id_usuario) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT fk_compra_estado  FOREIGN KEY (id_estado)
    REFERENCES estados (id_estado)  ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- Fin del script
-- ============================================================
