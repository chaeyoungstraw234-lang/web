</div><!-- /container -->

<footer class="footer mt-auto py-3 bg-light border-top">
  <div class="container text-center text-muted small">
    &copy; <?= date('Y') ?> <strong>compra.me</strong> &mdash; Sistema de Gestión de Gastos
  </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= $baseUrl ?? '' ?>js/validacion.js"></script>
</body>
</html>