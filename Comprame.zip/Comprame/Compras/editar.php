<?php
$pageTitle = 'Editar Compra';
$baseUrl   = '../../';
require_once '../../config/conexion.php';

$conn = getConexion();
$id   = intval($_GET['id'] ?? 0);

$stmt = $conn->prepare("SELECT * FROM compras WHERE id_compra = ?");
$stmt->bind_param('i', $id);
$stmt->execute();
$compra = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$compra) { header('Location: listar.php'); exit; }

$usuarios = $conn->query("SELECT id_usuario, nombre_usuario FROM usuarios ORDER BY nombre_usuario");
$estados  = $conn->query("SELECT id_estado, nombre_estado FROM estados ORDER BY id_estado");
$errores  = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $titulo      = trim($_POST['titulo']      ?? '');
    $descripcion = trim($_POST['descripcion'] ?? '');
    $fecha       = trim($_POST['fecha']       ?? '');
    $monto       = trim($_POST['monto']       ?? '');
    $usuario     = intval($_POST['usuario']   ?? 0);
    $estado      = intval($_POST['estado']    ?? 0);

    if (empty($titulo)) $errores[] = 'El título es obligatorio.';
    if (empty($fecha))  $errores[] = 'La fecha es obligatoria.';
    if ($usuario <= 0)  $errores[] = 'Selecciona un usuario.';
    if ($estado  <= 0)  $errores[] = 'Selecciona un estado.';
    if (!is_numeric($monto) || $monto < 0) $errores[] = 'Monto inválido.';

    if (empty($errores)) {
        $upd = $conn->prepare("UPDATE compras SET titulo_compra=?, descripcion_compra=?, fecha_ejecucion=?, monto=?, id_usuario_encargado=?, id_estado=? WHERE id_compra=?");
        $upd->bind_param('sssdiii', $titulo, $descripcion, $fecha, $monto, $usuario, $estado, $id);
        if ($upd->execute()) { header('Location: listar.php?msg=editado'); exit; }
        $errores[] = 'Error al actualizar.';
        $upd->close();
    }
    $compra['titulo_compra'] = $titulo; $compra['descripcion_compra'] = $descripcion;
    $compra['fecha_ejecucion'] = $fecha; $compra['monto'] = $monto;
    $compra['id_usuario_encargado'] = $usuario; $compra['id_estado'] = $estado;
}

require_once '../../config/header.php';
?>

<div class="breadcrumb-wrapper">
  <nav aria-label="breadcrumb">
    <ol class="breadcrumb mb-0">
      <li class="breadcrumb-item"><a href="<?= $baseUrl ?>index.php">Inicio</a></li>
      <li class="breadcrumb-item"><a href="listar.php">Compras</a></li>
      <li class="breadcrumb-item active">Editar</li>
    </ol>
  </nav>
</div>

<?php if (!empty($errores)): ?><div class="alert alert-danger"><ul class="mb-0"><?php foreach ($errores as $e): ?><li><?= $e ?></li><?php endforeach; ?></ul></div><?php endif; ?>

<div class="card mx-auto" style="max-width:640px">
  <div class="card-header bg-white"><i class="bi bi-pencil-fill me-2 text-secondary"></i>Editar Compra #<?= $id ?></div>
  <div class="card-body">
    <form method="POST" class="needs-validation" novalidate>
      <div class="mb-3">
        <label class="form-label" for="titulo">Título <span class="text-danger">*</span></label>
        <input type="text" id="titulo" name="titulo" class="form-control" required maxlength="150"
               value="<?= htmlspecialchars($compra['titulo_compra']) ?>">
        <div class="invalid-feedback">El título es obligatorio.</div>
      </div>
      <div class="mb-3">
        <label class="form-label" for="descripcion">Descripción</label>
        <textarea id="descripcion" name="descripcion" class="form-control" rows="3"><?= htmlspecialchars($compra['descripcion_compra'] ?? '') ?></textarea>
      </div>
      <div class="row g-3 mb-3">
        <div class="col-sm-6">
          <label class="form-label" for="fecha">Fecha de ejecución <span class="text-danger">*</span></label>
          <input type="date" id="fecha" name="fecha" class="form-control" required
                 value="<?= htmlspecialchars($compra['fecha_ejecucion']) ?>">
        </div>
        <div class="col-sm-6">
          <label class="form-label" for="monto">Monto (Q)</label>
          <input type="number" id="monto" name="monto" class="form-control" min="0" step="0.01"
                 value="<?= htmlspecialchars($compra['monto']) ?>">
        </div>
      </div>
      <div class="row g-3 mb-4">
        <div class="col-sm-6">
          <label class="form-label" for="usuario">Usuario encargado <span class="text-danger">*</span></label>
          <select id="usuario" name="usuario" class="form-select" required>
            <?php $usuarios->data_seek(0); while ($u = $usuarios->fetch_assoc()): ?>
            <option value="<?= $u['id_usuario'] ?>" <?= ($compra['id_usuario_encargado'] == $u['id_usuario']) ? 'selected' : '' ?>><?= htmlspecialchars($u['nombre_usuario']) ?></option>
            <?php endwhile; ?>
          </select>
        </div>
        <div class="col-sm-6">
          <label class="form-label" for="estado">Estado <span class="text-danger">*</span></label>
          <select id="estado" name="estado" class="form-select" required>
            <?php $estados->data_seek(0); while ($e = $estados->fetch_assoc()): ?>
            <option value="<?= $e['id_estado'] ?>" <?= ($compra['id_estado'] == $e['id_estado']) ? 'selected' : '' ?>><?= htmlspecialchars($e['nombre_estado']) ?></option>
            <?php endwhile; ?>
          </select>
        </div>
      </div>
      <div class="d-flex gap-2">
        <button type="submit" class="btn btn-primary"><i class="bi bi-save me-1"></i>Actualizar</button>
        <a href="listar.php" class="btn btn-outline-secondary">Cancelar</a>
      </div>
    </form>
  </div>
</div>

<?php $conn->close(); require_once '../../config/footer.php'; ?>
