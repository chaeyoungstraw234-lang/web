<?php
// config/bd.php

//parametros de conexion
$host = "sql107.infinityfree.com"; // servidor de base de datos
$user = "if0_41557592";  // usuario de la base de datos
$pass = "HejR4b8oPsY";  // contraseña del usuario
$db = "if0_41557592_comprame_bd";  //nombre de la base de datos

// crear conexion 
$conn = new mysqli ($host, $user, $pass, $db);

//verificar conexion


function getConexion() {
    $conn = new mysqli(
        "sql107.infinityfree.com", //  HOST
        "if0_41557592",            //  USUARIO
        "HejR4b8oPsY",           //  PASSWORD
        "if0_41557592_comprame_bd"        // BASE 
    );

    if ($conn->connect_error) {
        die("Error de conexión: " . $conn->connect_error);
    }

    return $conn;
}


?>