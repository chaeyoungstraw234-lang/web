# compra.me — Sistema de Gestión de Gastos
## Guía de instalación y despliegue

---

## Requisitos del servidor
- PHP 7.4 o superior (recomendado PHP 8.x)
- MySQL 5.7 o superior / MariaDB 10.4+
- Servidor web: Apache o Nginx con mod_rewrite activo
- Acceso FTP o panel de control (cPanel, Plesk, etc.)

---

## Estructura de archivos

```
comprame/
├── index.php                  ← Dashboard principal
├── database.sql               ← Script de base de datos
├── css/
│   └── estilos.css
├── js/
│   └── validacion.js
├── includes/
│   ├── conexion.php           ← ⚠️ Configurar credenciales
│   ├── header.php
│   └── footer.php
└── modulos/
    ├── usuarios/
    │   ├── listar.php
    │   ├── crear.php
    │   ├── editar.php
    │   └── eliminar.php
    ├── compras/
    │   ├── listar.php
    │   ├── crear.php
    │   ├── editar.php
    │   └── eliminar.php
    └── estados/
        ├── listar.php
        ├── crear.php
        ├── editar.php
        └── eliminar.php
```

---

## Paso 1 — Crear la base de datos

1. Ingresa a **phpMyAdmin** (o cualquier cliente MySQL).
2. Crea una base de datos nueva llamada `comprame_db` (o el nombre que prefieras).
3. Selecciona esa base de datos e importa el archivo `database.sql`.
4. Verifica que se hayan creado las tablas: `estados`, `usuarios`, `compras`.

---

## Paso 2 — Configurar la conexión

Edita el archivo `includes/conexion.php` con tus datos reales:

```php
define('DB_HOST', 'localhost');      // Host de MySQL (usualmente localhost)
define('DB_USER', 'tu_usuario');     // Usuario de MySQL
define('DB_PASS', 'tu_contraseña');  // Contraseña de MySQL
define('DB_NAME', 'comprame_db');    // Nombre de la base de datos
```

---

## Paso 3 — Subir archivos al servidor

**Opción A — FTP (FileZilla u otro cliente):**
1. Conéctate al servidor con tus credenciales FTP.
2. Navega a la carpeta `public_html/` (o `www/`, según el host).
3. Sube toda la carpeta `comprame/` manteniendo la estructura.

**Opción B — cPanel File Manager:**
1. Ingresa al cPanel de tu hosting.
2. Abre el Administrador de Archivos.
3. Navega a `public_html/`.
4. Sube y extrae el archivo ZIP del proyecto.

---

## Paso 4 — Probar el funcionamiento

Accede desde el navegador a:

```
https://tudominio.com/comprame/
```

Prueba cada módulo en este orden:
1. **Estados** → Agrega, edita y elimina estados.
2. **Usuarios** → Registra al menos un usuario.
3. **Compras** → Crea compras asignadas a usuarios con distintos estados.
4. **Dashboard** → Verifica que las estadísticas se reflejen correctamente.

---

## Hospedajes recomendados (PHP + MySQL gratuitos o de bajo costo)

| Proveedor         | Plan gratuito | PHP | MySQL | Notas                        |
|-------------------|:------------:|:---:|:-----:|------------------------------|
| InfinityFree      | ✅           | ✅  | ✅    | Sin anuncios, bueno para pruebas |
| FreeHosting.com   | ✅           | ✅  | ✅    | 10 GB almacenamiento          |
| Hostinger         | De pago      | ✅  | ✅    | Muy confiable, bajo costo     |
| 000WebHost        | ✅           | ✅  | ✅    | Fácil de usar                 |

---

## Seguridad implementada

- ✅ Sentencias preparadas (PDO/MySQLi) — previene inyección SQL
- ✅ `htmlspecialchars()` en todas las salidas — previene XSS
- ✅ Validación doble: cliente (JS) + servidor (PHP)
- ✅ Protección contra eliminación en cascada (restricciones FK)
- ✅ Verificación de integridad antes de eliminar registros relacionados

---

## Notas adicionales

- Cambia las credenciales de `conexion.php` antes de publicar.
- En producción, considera mover `conexion.php` fuera del directorio público.
- Activa HTTPS en tu hosting para proteger los datos en tránsito.
