<?php
$pageTitle = 'Usuarios';
$baseUrl   = '../../';
require_once '../../config/conexion.php';
require_once '../../config/header.php';

$conn    = getConexion();
$usuarios = $conn->query("SELECT * FROM usuarios ORDER BY nombre_usuario");

// Mensajes de retroalimentación
$msg = $_GET['msg'] ?? '';
?>

<div class="breadcrumb-wrapper">
  <nav aria-label="breadcrumb">
    <ol class="breadcrumb mb-0">
      <li class="breadcrumb-item"><a href="<?= $baseUrl ?>index.php">Inicio</a></li>
      <li class="breadcrumb-item active">Usuarios</li>
    </ol>
  </nav>
</div>

<?php if ($msg === 'creado'):   echo '<div class="alert alert-success alert-dismissible fade show" role="alert"><i class="bi bi-check-circle me-2"></i>Usuario creado correctamente.<button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>'; endif; ?>
<?php if ($msg === 'editado'):  echo '<div class="alert alert-info alert-dismissible fade show" role="alert"><i class="bi bi-pencil me-2"></i>Usuario actualizado correctamente.<button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>'; endif; ?>
<?php if ($msg === 'eliminado'):echo '<div class="alert alert-warning alert-dismissible fade show" role="alert"><i class="bi bi-trash me-2"></i>Usuario eliminado correctamente.<button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>'; endif; ?>

<div class="card">
  <div class="card-header bg-white d-flex justify-content-between align-items-center">
    <span><i class="bi bi-people-fill me-2 text-primary"></i>Listado de Usuarios</span>
    <a href="crear.php" class="btn btn-sm btn-primary">
      <i class="bi bi-plus-lg me-1"></i>Nuevo usuario
    </a>
  </div>
  <div class="card-body p-0">
    <div class="table-responsive">
      <table class="table table-hover mb-0">
        <thead class="table-light">
          <tr>
            <th>#</th>
            <th>Nombre</th>
            <th>Correo</th>
            <th>Teléfono</th>
            <th>Dirección</th>
            <th class="text-center">Acciones</th>
          </tr>
        </thead>
        <tbody>
          <?php if ($usuarios->num_rows === 0): ?>
            <tr><td colspan="6" class="text-center text-muted py-4">No hay usuarios registrados.</td></tr>
          <?php else: ?>
            <?php while ($u = $usuarios->fetch_assoc()): ?>
            <tr>
              <td class="text-muted"><?= $u['id_usuario'] ?></td>
              <td><?= htmlspecialchars($u['nombre_usuario']) ?></td>
              <td><?= htmlspecialchars($u['email_usuario']) ?></td>
              <td><?= htmlspecialchars($u['telefono_usuario'] ?? '—') ?></td>
              <td><?= htmlspecialchars($u['direccion_usuario'] ?? '—') ?></td>
              <td class="text-center">
                <a href="editar.php?id=<?= $u['id_usuario'] ?>" class="btn btn-accion btn-outline-secondary me-1" title="Editar">
                  <i class="bi bi-pencil-fill"></i>
                </a>
                <a href="eliminar.php?id=<?= $u['id_usuario'] ?>" class="btn btn-accion btn-outline-danger btn-confirmar-eliminar" title="Eliminar">
                  <i class="bi bi-trash-fill"></i>
                </a>
              </td>
            </tr>
            <?php endwhile; ?>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<?php $conn->close(); require_once '../../config/footer.php'; ?>
