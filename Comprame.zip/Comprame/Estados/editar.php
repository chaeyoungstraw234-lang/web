<?php
$pageTitle = 'Editar Estado';
$baseUrl   = '../../';
require_once '../../config/conexion.php';

$conn = getConexion();
$id   = intval($_GET['id'] ?? 0);

$stmt = $conn->prepare("SELECT * FROM estados WHERE id_estado = ?");
$stmt->bind_param('i', $id);
$stmt->execute();
$estado = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$estado) { header('Location: listar.php'); exit; }

$errores = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = trim($_POST['nombre'] ?? '');
    if (empty($nombre)) $errores[] = 'El nombre es obligatorio.';

    if (empty($errores)) {
        $upd = $conn->prepare("UPDATE estados SET nombre_estado=? WHERE id_estado=?");
        $upd->bind_param('si', $nombre, $id);
        if ($upd->execute()) { header('Location: listar.php?msg=editado'); exit; }
        $errores[] = 'Error: ' . htmlspecialchars($conn->error);
        $upd->close();
    }
    $estado['nombre_estado'] = $nombre;
}

$conn->close();
require_once '../../config/header.php';
?>

<div class="breadcrumb-wrapper">
  <nav aria-label="breadcrumb">
    <ol class="breadcrumb mb-0">
      <li class="breadcrumb-item"><a href="<?= $baseUrl ?>index.php">Inicio</a></li>
      <li class="breadcrumb-item"><a href="listar.php">Estados</a></li>
      <li class="breadcrumb-item active">Editar</li>
    </ol>
  </nav>
</div>

<?php if (!empty($errores)): ?><div class="alert alert-danger"><ul class="mb-0"><?php foreach ($errores as $e): ?><li><?= $e ?></li><?php endforeach; ?></ul></div><?php endif; ?>

<div class="card mx-auto" style="max-width:500px">
  <div class="card-header bg-white"><i class="bi bi-pencil-fill me-2 text-secondary"></i>Editar Estado #<?= $id ?></div>
  <div class="card-body">
    <form method="POST" class="needs-validation" novalidate>
      <div class="mb-4">
        <label class="form-label" for="nombre">Nombre del estado <span class="text-danger">*</span></label>
        <input type="text" id="nombre" name="nombre" class="form-control" required maxlength="50"
               value="<?= htmlspecialchars($estado['nombre_estado']) ?>">
        <div class="invalid-feedback">Este campo es obligatorio.</div>
      </div>
      <div class="d-flex gap-2">
        <button type="submit" class="btn btn-primary"><i class="bi bi-save me-1"></i>Actualizar</button>
        <a href="listar.php" class="btn btn-outline-secondary">Cancelar</a>
      </div>
    </form>
  </div>
</div>

<?php require_once '../../config/footer.php'; ?>